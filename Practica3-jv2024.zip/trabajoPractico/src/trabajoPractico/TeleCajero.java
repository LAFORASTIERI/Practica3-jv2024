package trabajoPractico;
import java.util.Scanner;


public class TeleCajero {
private static double saldo = 1000.0; // Saldo inicial
private static boolean tarjetaBloqueada = false; // Estado de la tarjeta
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
        int opcion;
        int respuesta = 1;
        do {
            mostrarMenu();
            System.out.print("Ingrese una opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    consultarSaldo();
                    break;
                case 2:
                    depositar(scanner);
                    break;
                case 3:
                    retirar(scanner);
                    break;
                case 4:
                    bloquearTarjeta();
                    break;
                case 5:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opción inválida. Por favor, ingrese una opción válida.");
                    continue;
            }
            
            if (opcion >= 1 && opcion <= 4) {
                System.out.print("¿Desea realizar otra operación? (1 - sí / 2 - no): ");
                respuesta = scanner.nextInt();
            } else {
                respuesta = 2; // Para salir del bucle sin preguntar si desea realizar otra operación
            }
                    } while (respuesta == 1);
        	System.out.println("¡Gracias por utilizar nuestros servicios, Hasta luego!");
    }

    private static void mostrarMenu() {
        System.out.println("Bienvenido al telecajero");
        System.out.println("1. Consultar saldo");
        System.out.println("2. Depositar dinero");
        System.out.println("3. Retirar dinero");
        System.out.println("4. Bloquear tarjeta");
        System.out.println("5. Salir");
    }

    private static void consultarSaldo() {
    	 if (tarjetaBloqueada) {
             System.out.println("Tarjeta bloqueada. No es posible realizar operaciones.");
             return;
         }
        System.out.println("Su saldo actual es: $" + saldo);
    }

    private static void depositar(Scanner scanner) {
        if (tarjetaBloqueada) {
            System.out.println("Tarjeta bloqueada. No es posible realizar operaciones.");
            return;
        }
        
        System.out.print("Ingrese la cantidad a depositar: ");
        double cantidad = scanner.nextDouble();
        saldo += cantidad;
        System.out.println("Depósito exitoso. Su nuevo saldo es: $" + saldo);
    }

    private static void retirar(Scanner scanner) {
        if (tarjetaBloqueada) {
            System.out.println("Tarjeta bloqueada. No es posible realizar operaciones.");
            return;
        }

        System.out.print("Ingrese la cantidad a retirar: ");
        double cantidad = scanner.nextDouble();
        if (cantidad > saldo) {
            System.out.println("Fondos insuficientes.");
        } else {
            saldo -= cantidad;
            System.out.println("Retiro exitoso. Su nuevo saldo es: $" + saldo);
        }
    }

    private static void bloquearTarjeta() {
        tarjetaBloqueada = true;
        System.out.println("Tarjeta bloqueada exitosamente.");
	}

}
